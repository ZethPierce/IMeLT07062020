-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 06, 2020 at 11:46 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `imelt_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_credentials`
--

CREATE TABLE `tbl_admin_credentials` (
  `id` int(11) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_admin_credentials`
--

INSERT INTO `tbl_admin_credentials` (`id`, `last_name`, `first_name`, `middle_name`, `username`, `password`) VALUES
(1, 'Admin', 'Admin', 'Admin', 'sysadmin', 'syspassword');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_answers`
--

CREATE TABLE `tbl_answers` (
  `answer_id` int(11) NOT NULL,
  `answer` varchar(200) NOT NULL,
  `ans_id` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_lesson_contents`
--

CREATE TABLE `tbl_lesson_contents` (
  `module_id` int(12) NOT NULL,
  `module_num` varchar(26) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `lesson_contents` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_lesson_contents`
--

INSERT INTO `tbl_lesson_contents` (`module_id`, `module_num`, `module_name`, `lesson_contents`) VALUES
(1, 'Module 1', 'Earth\'s Atmosphere ', 'Component of the Earth\'s Atmosphere'),
(2, 'Module 1', 'Earth\'s Atmosphere', 'Vertical Structure of the Atmosphere'),
(3, 'Module 2', 'Warming and Cooling Earth and its Atmosphere', 'Temperature and Heat Transfer'),
(4, 'Module 2', 'Warming and Cooling Earth and its Atmosphere', 'Radiant Energy'),
(5, 'Module 2', 'Warming and Cooling Earth and its Atmosphere', 'Radiation-Absorption, Emission and Equilibrium'),
(6, 'Module 2', 'Warming and Cooling Earth and its Atmosphere', 'Earth\"s Seasons'),
(7, 'Module 3', 'Air Temperature', 'Warming and Cooling Air Near the Surface'),
(8, 'Module 3', 'Air Temperature', 'Measuring Air Temperature'),
(9, 'Module 4', 'Humidity, Condensation and Clouds', 'Circulation of Water in the Atmosphere'),
(10, 'Module 4', 'Humidity, Condensation and Clouds', 'Evaporation, Condensation, and Saturation'),
(11, 'Module 4', 'Humidity, Condensation and Clouds', 'Humidity'),
(12, 'Module 4', 'Humidity, Condensation and Clouds', 'Dew and Frost'),
(13, 'Module 4', 'Humidity, Condensation and Clouds', 'Fog'),
(14, 'Module 4', 'Humidity, Condensation and Clouds', 'Foggy Weather'),
(15, 'Module 4', 'Humidity, Condensation and Clouds', 'Clouds'),
(16, 'Module 5', 'Cloud Development and Precipitation', 'Atmospheric Stability'),
(17, 'Module 5', 'Cloud Development and Precipitation', 'Cloud Development and Stability'),
(18, 'Module 5', 'Cloud Development and Precipitation', 'Precipitation Process'),
(19, 'Module 6', 'Air Pressure and Winds', 'Atmospheric Pressure'),
(20, 'Module 6', 'Air Pressure and Winds', 'Winds and Vertical Air Motions');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_modules`
--

CREATE TABLE `tbl_modules` (
  `module_id` int(12) NOT NULL,
  `module_num` varchar(26) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `lesson_contents` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_modules`
--

INSERT INTO `tbl_modules` (`module_id`, `module_num`, `module_name`, `lesson_contents`) VALUES
(1, 'Module 1', 'Earth\'s Atmosphere ', 'Component of the Earth\'s Atmosphere'),
(2, 'Module 1', 'Earth\'s Atmosphere', 'Vertical Structure of the Atmosphere'),
(3, 'Module 2', 'Warming and Cooling Earth and its Atmosphere', 'Temperature and Heat Transfer'),
(4, 'Module 2', 'Warming and Cooling Earth and its Atmosphere', 'Radiant Energy'),
(5, 'Module 2', 'Warming and Cooling Earth and its Atmosphere', 'Radiation-Absorption, Emission and Equilibrium'),
(6, 'Module 2', 'Warming and Cooling Earth and its Atmosphere', 'Earth\"s Seasons'),
(7, 'Module 3', 'Air Temperature', 'Warming and Cooling Air Near the Surface'),
(8, 'Module 3', 'Air Temperature', 'Measuring Air Temperature'),
(9, 'Module 4', 'Humidity, Condensation and Clouds', 'Circulation of Water in the Atmosphere'),
(10, 'Module 4', 'Humidity, Condensation and Clouds', 'Evaporation, Condensation, and Saturation'),
(11, 'Module 4', 'Humidity, Condensation and Clouds', 'Humidity'),
(12, 'Module 4', 'Humidity, Condensation and Clouds', 'Dew and Frost'),
(13, 'Module 4', 'Humidity, Condensation and Clouds', 'Fog'),
(14, 'Module 4', 'Humidity, Condensation and Clouds', 'Foggy Weather'),
(15, 'Module 4', 'Humidity, Condensation and Clouds', 'Clouds'),
(16, 'Module 5', 'Cloud Development and Precipitation', 'Atmospheric Stability'),
(17, 'Module 5', 'Cloud Development and Precipitation', 'Cloud Development and Stability'),
(18, 'Module 5', 'Cloud Development and Precipitation', 'Precipitation Process'),
(19, 'Module 6', 'Air Pressure and Winds', 'Atmospheric Pressure'),
(20, 'Module 6', 'Air Pressure and Winds', 'Winds and Vertical Air Motions');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_module_name`
--

CREATE TABLE `tbl_module_name` (
  `module_id` int(12) NOT NULL,
  `module_num` varchar(26) NOT NULL,
  `module_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_module_name`
--

INSERT INTO `tbl_module_name` (`module_id`, `module_num`, `module_name`) VALUES
(1, 'Module 1', 'Earth\'s Atmosphere'),
(2, 'Module 2', 'Warming and Cooling Earth and its Atmosphere'),
(3, 'Module 3', 'Air Temperature'),
(4, 'Module 4', 'Humidity, Condensation and Clouds'),
(5, 'Module 5', 'Cloud Development and Precipitation'),
(6, 'Module 6', 'Air Pressure and Winds');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_module_num`
--

CREATE TABLE `tbl_module_num` (
  `module_id` int(12) NOT NULL,
  `module_num` varchar(26) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_module_num`
--

INSERT INTO `tbl_module_num` (`module_id`, `module_num`) VALUES
(1, 'Module 1'),
(2, 'Module 2'),
(3, 'Module 3'),
(4, 'Module 4'),
(5, 'Module 5'),
(6, 'Module 6');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_module_questions`
--

CREATE TABLE `tbl_module_questions` (
  `module_id` int(12) NOT NULL,
  `module_num` varchar(26) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `module_question_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_module_questions`
--

INSERT INTO `tbl_module_questions` (`module_id`, `module_num`, `module_name`, `module_question_id`) VALUES
(1, 'Module 1', 'Earth\'s Atmosphere', 1),
(2, 'Module 2', 'Warming and Cooling Earth and its Atmosphere', 2),
(3, 'Module 3', 'Air Temperature', 0),
(4, 'Module 4', 'Humidity, Condensation and Clouds', 0),
(5, 'Module 5', 'Cloud Development and Precipitation', 0),
(6, 'Module 6', 'Air Pressure and Winds', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_per_module`
--

CREATE TABLE `tbl_per_module` (
  `general_id` int(3) NOT NULL,
  `module_question_id` int(3) NOT NULL,
  `question_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_per_module`
--

INSERT INTO `tbl_per_module` (`general_id`, `module_question_id`, `question_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7),
(8, 1, 8),
(9, 1, 9),
(10, 1, 10),
(11, 1, 11),
(12, 1, 12),
(13, 1, 13),
(14, 1, 14),
(15, 1, 15),
(16, 1, 16),
(17, 1, 17),
(18, 1, 18),
(19, 1, 19),
(20, 1, 20),
(21, 2, 21),
(22, 2, 22),
(23, 2, 23),
(24, 2, 24),
(25, 2, 25),
(26, 2, 26),
(27, 2, 27),
(28, 2, 28),
(29, 2, 29),
(30, 2, 30),
(31, 2, 31),
(32, 2, 32),
(33, 2, 33),
(34, 2, 34),
(35, 2, 35),
(36, 2, 36),
(37, 2, 37),
(38, 2, 38),
(39, 2, 39),
(40, 2, 40),
(41, 3, 41),
(42, 3, 42),
(43, 3, 43),
(44, 3, 44),
(45, 3, 45),
(46, 3, 46),
(47, 3, 47),
(48, 3, 48),
(49, 3, 49),
(50, 3, 50),
(51, 3, 51),
(52, 3, 52),
(53, 3, 53),
(54, 3, 54),
(55, 3, 55),
(56, 3, 56),
(57, 3, 57),
(58, 3, 58),
(59, 3, 59),
(60, 3, 60),
(61, 4, 61),
(62, 4, 62),
(63, 4, 63),
(64, 4, 64),
(65, 4, 65),
(66, 4, 66),
(67, 4, 67),
(68, 4, 68),
(69, 4, 69),
(70, 4, 70),
(71, 4, 71),
(72, 4, 72),
(73, 4, 73),
(74, 4, 74),
(75, 4, 75),
(76, 4, 76),
(77, 4, 77),
(78, 4, 78),
(79, 4, 79),
(80, 4, 80),
(81, 5, 81),
(82, 5, 82),
(83, 5, 83),
(84, 5, 84),
(85, 5, 85),
(86, 5, 86),
(87, 5, 87),
(88, 5, 88),
(89, 5, 89),
(90, 5, 90),
(91, 5, 91),
(92, 5, 92),
(93, 5, 93),
(94, 5, 94),
(95, 5, 95),
(96, 5, 96),
(97, 5, 97),
(98, 5, 98),
(99, 5, 99),
(100, 5, 100),
(101, 6, 101),
(102, 6, 102),
(103, 6, 103),
(104, 6, 104),
(105, 6, 105),
(106, 6, 106),
(107, 6, 107),
(108, 6, 108),
(109, 6, 109),
(110, 6, 110),
(111, 6, 111),
(112, 6, 112),
(113, 6, 113),
(114, 6, 114),
(115, 6, 115),
(116, 6, 116),
(117, 6, 117),
(118, 6, 118),
(119, 6, 119),
(120, 6, 120);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_possible_answer`
--

CREATE TABLE `tbl_possible_answer` (
  `general_id` int(3) NOT NULL,
  `possible_answer_id` int(3) NOT NULL,
  `possible_answer` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_possible_answer`
--

INSERT INTO `tbl_possible_answer` (`general_id`, `possible_answer_id`, `possible_answer`) VALUES
(1, 1, 'True'),
(2, 1, 'False'),
(3, 2, 'True'),
(4, 2, 'False'),
(5, 3, 'True'),
(6, 3, 'False'),
(7, 4, 'True'),
(8, 4, 'False'),
(9, 5, 'True'),
(10, 5, 'False'),
(11, 6, 'Mercury'),
(12, 7, 'Acid Rain'),
(13, 8, 'Ammonia'),
(14, 9, '36,500 ft'),
(15, 9, '36,000 ft'),
(16, 9, '37,000 ft'),
(17, 9, '37,500 ft'),
(18, 10, 'Relative Humidity'),
(19, 10, 'Lapse Rate'),
(20, 10, 'Wind Chill'),
(21, 10, 'Dew - Point'),
(22, 11, 'Freezing Point'),
(23, 11, 'Neutral Point'),
(24, 11, 'Temperature Inversion'),
(25, 11, 'Corporate Inversion'),
(26, 12, 'Radiosonde'),
(27, 12, 'Sling Psychrometer'),
(28, 12, 'Barometer'),
(29, 12, 'Anemometer'),
(30, 13, '30 km'),
(31, 13, '25 km'),
(32, 13, '35 km'),
(33, 13, '40 km'),
(34, 14, 'Ketone'),
(35, 14, 'Thermodynamics'),
(36, 14, 'Occurence'),
(37, 14, 'Air Density'),
(38, 15, '5600 Billion'),
(39, 15, '5600 Trillion'),
(40, 15, '6600 Billion'),
(41, 15, '6600 Trillion'),
(42, 16, 'Blood Heat'),
(43, 16, 'Calorific'),
(44, 16, 'Absorbance'),
(45, 16, 'Latent Heat'),
(46, 17, 'Hydrolysis'),
(47, 17, 'Chemical Weathering'),
(48, 17, 'Erosion'),
(49, 17, 'Decomposition'),
(50, 18, '0.4'),
(51, 18, '0.04'),
(52, 18, '0.004'),
(53, 18, '0.0004'),
(54, 19, 'Anthropogenic'),
(55, 19, 'Coating'),
(56, 19, 'Photochemical Smog'),
(57, 19, 'Plating'),
(58, 20, 'Less, Goes Down'),
(59, 20, 'More, Goes Down'),
(60, 20, 'Less, Goes Up'),
(61, 20, 'More, Goes Up');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_progress`
--

CREATE TABLE `tbl_progress` (
  `general_id` int(11) NOT NULL,
  `progress_id` int(3) NOT NULL,
  `progress_details_id` int(3) NOT NULL,
  `module_id` int(3) NOT NULL,
  `progress_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_progress`
--

INSERT INTO `tbl_progress` (`general_id`, `progress_id`, `progress_details_id`, `module_id`, `progress_status`) VALUES
(1, 1, 1, 1, 'unlocked'),
(2, 1, 0, 2, 'locked'),
(3, 1, 0, 3, 'locked'),
(4, 1, 0, 4, 'locked'),
(5, 1, 0, 5, 'locked'),
(6, 1, 0, 6, 'locked');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_progress_details`
--

CREATE TABLE `tbl_progress_details` (
  `general_id` int(11) NOT NULL,
  `progress_details_id` int(5) NOT NULL,
  `question_id` int(3) NOT NULL,
  `test_type` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `scores` int(5) NOT NULL,
  `user_answer` varchar(60) NOT NULL,
  `username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_progress_details`
--

INSERT INTO `tbl_progress_details` (`general_id`, `progress_details_id`, `question_id`, `test_type`, `status`, `scores`, `user_answer`, `username`) VALUES
(111, 1, 14, 'pre', 0, 0, '', 'mikee04'),
(112, 1, 4, 'pre', 1, 10, '', 'mikee04'),
(113, 1, 6, 'pre', 0, 0, '', 'mikee04'),
(114, 1, 20, 'pre', 0, 0, '', 'mikee04'),
(115, 1, 1, 'pre', 0, 0, '', 'mikee04'),
(116, 1, 9, 'pre', 0, 0, '', 'mikee04'),
(117, 1, 2, 'pre', 0, 0, '', 'mikee04'),
(118, 1, 15, 'pre', 1, 10, '', 'mikee04'),
(119, 1, 18, 'pre', 1, 10, '', 'mikee04'),
(120, 1, 8, 'pre', 0, 0, '', 'mikee04');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_questions`
--

CREATE TABLE `tbl_questions` (
  `question_id` int(3) NOT NULL,
  `possible_answer_id` int(3) NOT NULL,
  `question_q` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `question_answer` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `question_optionize` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_questions`
--

INSERT INTO `tbl_questions` (`question_id`, `possible_answer_id`, `question_q`, `question_answer`, `question_optionize`) VALUES
(1, 1, 'Normal atmospheric pressure near sea level is close to 14.6 pounds per square.', 'False', 1),
(2, 2, 'A change in air density can bring about a change in air pressure.', 'True', 1),
(3, 3, 'The amount of force exerted over an area of surface is called atmospheric pressure. ', 'True', 1),
(4, 4, 'Occasionally, the air temperature may actually increase with height, producing a condition known as a temperature inversion.', 'True', 1),
(5, 5, 'The Earth\'s first atmosphere was most likely nitrogen and hydrogen -- the two most abundant gases found in the universe-as well as hydrogen compounds, such as methane (CH4) and ammonia (NH3)', 'False', 1),
(6, 6, 'A more traditional unit of pressure is _________(Hg), which is commonly used both in the field of aviation and in weather reports on television, radio, smartphones, and the Internet.', 'Mercury', 0),
(7, 7, '______ is a major environmental problem, especially downwind from major industrial areas.', 'Acid Rain', 0),
(8, 8, 'What does NH3 stands for?', 'Ammonia', 0),
(9, 9, 'Air temperature normally decreases from Earth\'s surface up to an altitude of about 11 km, which is nearly _______ or 7 mi.', '36,000 ft', 1),
(10, 10, 'The rate at which the air temperature decreases with height is called the temperature _______. ', 'Lapse Rate', 1),
(11, 11, 'Occasionally, the air temperature may actually increase with height, producing a condition known as a ________.', 'Temperature Inversion', 1),
(12, 12, 'The instrument that measures the vertical profile of air temperature in the atmosphere up to an altitude sometimes exceeding 30 km (100,000 ft) is the _______.', 'Radiosonde', 1),
(13, 13, 'The instrument that measures the vertical profile of air temperature in the atmosphere up to an altitude sometimes exceeding ___ km (100,000 ft) is the radiosonde.', '30 km', 1),
(14, 14, '_____ is the number of air molecules in a given space (volume).', 'Air Density', 1),
(15, 15, 'The weight of all the air around Earth is a staggering _______ tons.', '5600 Trillion', 1),
(16, 16, 'It is an important source of atmospheric energy, especially for storms, such as thunderstorms and hurricanes.', 'Latent Heat', 1),
(17, 17, 'Rain and snow can react with silicate minerals in rocks and remove CO2 from the atmosphere through a process known as _______. ', 'Chemical Weathering', 1),
(18, 18, '_____ is the number of air molecules in a given space (volume).', '0.04', 1),
(19, 19, 'On Earth\'s surface, ozone (O3) is the primary ingredient of __________, which irritates the eyes and throat and damages vegetation.', 'Photochemical Smog', 1),
(20, 20, 'If more molecules are packed into the column, it becomes denser, the air weighs _______, and the surface pressure _________.', 'More, Goes Up', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_credentials`
--

CREATE TABLE `tbl_user_credentials` (
  `id` int(11) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  `user_progress_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_credentials`
--

INSERT INTO `tbl_user_credentials` (`id`, `last_name`, `first_name`, `middle_name`, `username`, `password`, `user_progress_id`) VALUES
(1, 'Lastica', 'Mark ', 'Aldrin', 'markaldrin04', 'markaldrin04', 0),
(2, 'Bragais', 'Mikee', '', 'mikee04', 'mikee04', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin_credentials`
--
ALTER TABLE `tbl_admin_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_answers`
--
ALTER TABLE `tbl_answers`
  ADD PRIMARY KEY (`answer_id`);

--
-- Indexes for table `tbl_lesson_contents`
--
ALTER TABLE `tbl_lesson_contents`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `tbl_modules`
--
ALTER TABLE `tbl_modules`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `tbl_module_name`
--
ALTER TABLE `tbl_module_name`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `tbl_module_num`
--
ALTER TABLE `tbl_module_num`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `tbl_module_questions`
--
ALTER TABLE `tbl_module_questions`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `tbl_per_module`
--
ALTER TABLE `tbl_per_module`
  ADD PRIMARY KEY (`general_id`);

--
-- Indexes for table `tbl_possible_answer`
--
ALTER TABLE `tbl_possible_answer`
  ADD PRIMARY KEY (`general_id`);

--
-- Indexes for table `tbl_progress`
--
ALTER TABLE `tbl_progress`
  ADD PRIMARY KEY (`general_id`);

--
-- Indexes for table `tbl_progress_details`
--
ALTER TABLE `tbl_progress_details`
  ADD PRIMARY KEY (`general_id`);

--
-- Indexes for table `tbl_questions`
--
ALTER TABLE `tbl_questions`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `tbl_user_credentials`
--
ALTER TABLE `tbl_user_credentials`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin_credentials`
--
ALTER TABLE `tbl_admin_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_answers`
--
ALTER TABLE `tbl_answers`
  MODIFY `answer_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_lesson_contents`
--
ALTER TABLE `tbl_lesson_contents`
  MODIFY `module_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_modules`
--
ALTER TABLE `tbl_modules`
  MODIFY `module_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_module_name`
--
ALTER TABLE `tbl_module_name`
  MODIFY `module_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_module_num`
--
ALTER TABLE `tbl_module_num`
  MODIFY `module_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_module_questions`
--
ALTER TABLE `tbl_module_questions`
  MODIFY `module_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_per_module`
--
ALTER TABLE `tbl_per_module`
  MODIFY `general_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `tbl_possible_answer`
--
ALTER TABLE `tbl_possible_answer`
  MODIFY `general_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `tbl_progress`
--
ALTER TABLE `tbl_progress`
  MODIFY `general_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_progress_details`
--
ALTER TABLE `tbl_progress_details`
  MODIFY `general_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `tbl_questions`
--
ALTER TABLE `tbl_questions`
  MODIFY `question_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_user_credentials`
--
ALTER TABLE `tbl_user_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
