<?php 
session_start();
include 'connection.php';
$username_session = $_SESSION['username'];
if (isset($_GET['useranswer'])) {
	$username_session = $_SESSION['username'];
	$data = json_decode($_GET['useranswer']);
	$query = mysqli_query($conn,"select tbl_progress.progress_details_id as pid
								from tbl_progress
								where tbl_progress.progress_id = ".$_GET['user_id']." and tbl_progress.module_id = ".$_GET['module_num'].";");
	$username_session = $_SESSION['username'];

	$row = mysqli_fetch_assoc($query);

	$default = 0;

	foreach ($data as $item) {
		$username_session = $_SESSION['username'];
		$query = mysqli_query($conn,"insert into tbl_progress_details(progress_details_id,question_id,test_type,status, scores, username) values(
			".$row['pid'].",
			". $item->id .",
			'pre',
			".$item->status.",
			".$item->scores.",
			'$username_session')");
		if ($query) {
			$default++;
		}
	}
	if ($default == 10) echo 'insert';
	else echo 'error';
} else {
	echo 'user_answer not set';
}



 ?>