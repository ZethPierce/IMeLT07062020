<?php

// Ganito mag hash una2
$password = 'mypassword';

$hashed = password_hash($password, PASSWORD_BCRYPT);

// ganito mag check

if(password_verify($password, $hashed))
{
	
}