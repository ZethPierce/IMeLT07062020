<?php 
session_start();
include('connection.php');
include('tags.php');
include('sidebar.php');
?>   



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IMeLT</title>
    <link rel="stylesheet" type="text/css" href="assets/css/login.css">
    
</head>
<body>
<?php 
$res = mysqli_query($conn, "select tbl_progress.module_id as module_num, tbl_module_name.module_name, tbl_progress.progress_status as status
from tbl_progress, tbl_module_name
where tbl_progress.progress_id = ".$_SESSION['progress_id']." and tbl_module_name.module_id = tbl_progress.module_id");
      if($res){
        $rowcount = mysqli_num_rows($res);
      }
?>

<div class="container" style="max-width: 800px;">
	
    <center>
    	<!--
  <a href="../index.php"><img src="assets/img/IMeLTLogo.png" class="mx-auto img-fluid" width="250" /></a>
-->
</center>

  <br>
  <div class="" style="margin-top: -20px;"> <!-- lineBorder -->
    <!--START OF MODULE FOR TICKET DISPLAY (ADMIN DISPLAY)-->
    <br>    
        <div class="row">
            <div class="col-lg-12">
              	<div class="form-group">
                 <?php while($row = mysqli_fetch_array($res)){
                  
                if($row['status']=='unlocked'){
                  echo '<a href="pre-test.php?m='.$row["module_num"].'">
                            <div class="btn-group-vertical buttonQuizPage" style="">
                '.$row["module_num"], " - ", $row["module_name"], " - Unlocked "; echo "" .'
                            </div>
                          </a>
                          ';
                }
                else {
                 echo '<a href="#" class="disabled" data-toggle="modal" data-target="#locked">
                          <div class="btn-group-vertical buttonQuizPage2" style="">
                          '.$row["module_num"]; echo " - "; echo $row["module_name"]; echo " - Locked ".  '
                          </div>
                        </a>
                          ';
                }
                
                //  echo '<a href="pre-test.php?m='.$row["module_num"].'">
                //             <div class="btn-group-vertical buttonQuizPage" style="">
                // '.$row["module_num"], " - ", $row["module_name"], " - Unlocked "; echo "" .'
                //             </div>
                //           </a>
                //           ';
                        }
                ?>
                </div>
            </div>
        </div>
        <br>
    </div>
</div>

<!-- MODAL FOR UNLOCKED 
<div class="modal fade" id="unlocked">
  <div class="modal-dialog modal-dialog-centered">
      <div class="modal-body">
        <a href="pre-test.php">
          <button class="btn btn-block buttonQuizPage">Start a Pre-test</button>
        </a>
      </div>
  </div>
</div>
-->
<!-- MODAL FOR LOCKED -->
<div class="modal fade" id="locked">
  <div class="modal-dialog modal-dialog-centered">
      <div class="modal-body">
        <button class="buttonQuizPage2">This module is locked. You should be able to take pre-test and post-test to unlock this module.</button>
      </div>
  </div>
</div>




</body>
</html>
