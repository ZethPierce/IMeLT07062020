<?php 
session_start();
include('connection.php');
include('tags.php');
include('sidebar.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IMeLT</title>
    <link rel="stylesheet" type="text/css" href="assets/css/login.css">
</head>
<body>
<div class="container">
	<div class="row">
		<div class="lead padding-compress">
			<center>
			<?php
			$username = $_SESSION['username'];
			$res = mysqli_query($conn, "SELECT SUM(status) AS status FROM tbl_progress_details WHERE username='$username'");
			while($row = mysqli_fetch_array($res)){
				if($row['status'] < 7){

					echo '
							<div class="border border-danger rounded p-4">
								<p class="text-danger">You answered '.$row['status'].' out of 10 . The result of your pre-test is <b>Failed</b>. 
								</p>
							</div>
						  ';
				}
				else {
					echo '
							<div class="border border-success p-4">
								<p class="text-success">You answered '.$row['status'].' out of 10 . The result of your pre-test is Passed. 
								</p>
							</div>
						
						  ';
				}
				echo '<br>

				<a href="lesson.php">
						<button class="btn btn-outline-primary">Proceed to Lesson </button>
					  </a>';
			}
			
				

			
			?>
				
		</div>
	</div>
</div>
</body>
</html>
