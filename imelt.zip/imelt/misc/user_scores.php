<?php 
session_start();
include('connection.php');
include('tags.php');
include('sidebar.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IMeLT</title>
    <link rel="stylesheet" type="text/css" href="assets/css/login.css">
</head>
<body>
<?php 
	$_SESSION['progress_id'];
	$res = mysqli_query($conn, "SELECT * FROM tbl_progress_details WHERE username='$username' AND test_type='pre'");
?>
<table>
	<thead>
		<tr>
			<th></th>
		</tr>
	</thead>
	<tbody>
		<?php while($row = mysqli_fetch_array($res)): ?>
			<tr>
				<td><?=$row['columns mo']?></td>
			</tr>
		<?php endwhile; ?>
	</tbody>
</table>
</body>
</html>
