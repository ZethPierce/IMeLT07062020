<?php 
   $conn = mysqli_connect("localhost", "root", "", "imelt_db");
                 
?>