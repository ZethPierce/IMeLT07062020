<?php 
include('connection.php');
include('tags.php');
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IMeLT</title>
    <link rel="stylesheet" type="text/css" href="assets/css/login.css">
    
</head>
<body>
<?php 
if(isset($_POST["login"]))
{
$count = 0;    
$username = $_POST['username'];  
$password = $_POST['password'];  
$res = mysqli_query($conn, "SELECT username, user_progress_id FROM tbl_user_credentials WHERE username='$username' && password='$password' ");
$count = mysqli_num_rows($res);    

    if($count == 0) { 
    echo '<div class="alert alert-danger alertClass">
    <center>
    <!--  <button type="button" class="close" data-dismiss="alert">&times;</button> -->

    <strong>Invalid</strong> Username Or Password.
    </center>
    </div> ';
    }
    else { 

        $row = mysqli_fetch_assoc($res);

        $_SESSION["username"] = $username;
        $_SESSION['progress_id'] = $row["user_progress_id"];
        
            header("Location: quiz_page.php");
        }

    
}
?>

<div class="container" style="max-width: 800px;">
    <center>
  <a href="../index.php"><img src="assets/img/IMeLTLogo.png" class="mx-auto img-fluid" width="250" /></a>
  <br><br>
</center>
  <br>
  <div class="lineBorder" style="margin-top: -90px;">
    <!--START OF MODULE FOR TICKET DISPLAY (ADMIN DISPLAY)-->


    <br>    
        <div class="row">
            <div class="col-lg-6">
                <img src="assets/img/mobile_app.png" class="loginDesign">
            </div>
                <div class="col-lg-6">
                <form action="" method="post">
                    <h5 style="margin-bottom: 15px;">Login as Student</h5>
                    <div class="form-group-sm">
                        <input type="text" name="username" placeholder="Enter your username" class="form-control form-control-sm inputClass" style="" maxlength="15" required>
                        <input type="password" name="password" placeholder="Enter your password" class="form-control form-control-sm inputClass" maxlength="15" required>
                    </div>
                    <div class="form-group-sm" style="margin-top: 14px; margin-bottom: 10px;">
                        <span><input type="submit" class="btn btn-block btn-primary buttonClass" value="LOGIN" name="login"></span>
                    </div>
                    <center>
                        <a href="register.php" class="text-center" style="margin-top: 14px !important;">No account? Click this to sign up.</a>
                    </center>
                </form>
            </div>
        </div>
        <br>
    </div>
</div>
</body>
</html>
