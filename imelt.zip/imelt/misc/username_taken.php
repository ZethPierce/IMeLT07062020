<?php 
include('connection.php');
if(isset($_POST['username'])){
	$count = 0;
	$username = $_POST['username'];
	$query = mysqli_query($conn, "SELECT * FROM tbl_user_credentials WHERE username='$username'");

	if(mysqli_num_rows($query) > 0){
		echo '<span class="text-danger">Username already taken</span>';
	}
	else{
		echo '<span class="text-success">Username available</span>';
	}

}

?>