const controller = (function() {
	let answers = [];

	return {
		setAnswer(id,answer) {
			answers.push(Object.assign({},{id,answer}));
		}
	};
})();