<?php 
session_start();
include('connection.php');
include('tags.php');
include('sidebar.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IMeLT</title>
    <link rel="stylesheet" type="text/css" href="assets/css/login.css">
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
</head>
<body>

<div class="container">
	<div class="row">
		<div class="lead padding-compress">
			<?php

			$username = $_SESSION['username'];
			$validation_q = mysqli_query($conn, "SELECT * FROM tbl_progress_details WHERE username='$username' AND test_type='pre'");
			if(mysqli_num_rows($validation_q) > 0){
				echo '<script>window.location.href = "result.php";</script>';
				// header("Location: result.php");
			}
			
			



				if (isset($_GET['m']) and trim($_GET['m']) != '') {
					// echo $_GET['m'];
					$questions_q = mysqli_query($conn, "select 
													tbl_questions.question_q,
												    tbl_questions.question_answer,
												    tbl_questions.question_optionize,
												    tbl_questions.possible_answer_id,
												    tbl_questions.question_id,
												    tbl_questions.question_answer
												FROM
													tbl_per_module,
												    tbl_questions
												 
												WHERE
													tbl_per_module.module_question_id = ".$_GET['m']." AND
													tbl_questions.question_id = tbl_per_module.question_id
												ORDER BY 
													RAND() LIMIT 10   
												    "); 


					 
					
					echo '<center>
					<h3> Module # '. $_GET["m"].' - Pre-test. </h3>
					<h5>In fill in the blank questions, always capitalize the first letter. (e.g. Sample / Sample Answer)</h5>
					</center><br>';
					$i = 1;
					// $current_question_ids = [];
					echo '<script>
							const controller = (function() {
								let answers = [];
								let ids = [];

								return {
									setAnswer(id,answer) {
										answers.push(Object.assign({},{id,answer,status:0,scores:0}));
										ids.push(id);
									},
									getAnswer() {
										console.log(answers);
									},
									validate() {
										for(let i = 0;i < ids.length;i++) {
										    let node_opt = document.getElementsByName(`opt-${ids[i]}`);
										    if (node_opt) {
										        if (node_opt.length > 1) {
										            node_opt.forEach(e => {
										            	if (e.checked) {
										            		if (answers[i].answer == e.getAttribute(\'aria-value\')) {
										            			answers[i].status = 1;
										            			answers[i].scores = 10;
										            		}
										            	}
										            });
										        } else {
										            if (node_opt[0].value.trim() == answers[i].answer) {
										            	answers[i].status = 1;
										            	answers[i].scores = 10;
										            }
										        }
										    }
										}
    									axios.get(\'http://localhost/imelt/misc/validate-test.php\',
    											{
    												params: {
    													useranswer: JSON.stringify(answers),
    													user_id: '. $_SESSION["progress_id"] .',
    													module_num: '.$_GET["m"].'	
    												}
    											}
    										).then(response => {
    											if (response.data == \'insert\')
    												location.reload();
    											})
    										.catch(error => console.log(error))
									}
								};
							})();
						</script>';
					while($row = mysqli_fetch_array($questions_q)){
						
						$question = '';
						if ($i == 1) {
							$question .= '<p class="text-dark">';
						} else {
							$question .= '<p class="text-dark ">';
						}
						$question .= $i.'. '.$row['question_q'].'</p>';		
						echo $question;
						echo '<script>
							controller.setAnswer('.$row["question_id"].',"'.$row["question_answer"].'")
						</script>';
						// array_push($current_question_ids,$row['question_id']);
						// for ($q_id = 0;$q_id < count($current_question_ids);$q_id++) {
							$selections = mysqli_query($conn, "SELECT tbl_possible_answer.possible_answer, tbl_questions.question_optionize, tbl_possible_answer.possible_answer_id FROM tbl_possible_answer, tbl_questions WHERE tbl_questions.question_id = ".  $row['question_id'] ." and tbl_possible_answer.possible_answer_id = tbl_questions.possible_answer_id");
							
							while($row = mysqli_fetch_array($selections)){
									if ($row["question_optionize"]) {
										echo '<div class="form-check-inline">
											   	<label class="form-check-label">
											  		<input aria-value="'.$row["possible_answer"].'" type="radio" class="form-check-input" name="opt-'.$row["possible_answer_id"].'">'
											  		.$row["possible_answer"].'
											 	</label>
												</div><br />';		
									} else {
										echo '<div class="form-group">
												<input type="text" class="form-control" name="opt-'.$row["possible_answer_id"].'" />
											 </div>';
									}
									
								}
						// }


						$i++;
					}	

					echo '<br><input type="submit" onclick="controller.validate()" class="btn btn-lg btn-primary" name="submit-answer" value="Submit Answer"/>';	
					
							if(isset($_POST['submit-answer'])){
									// wala pa akong nalalagay dito.
						
							}
					}
			?>	
		</div>
	</div>
</div>




<!-- Pagination

<div class="container p-4">
  <ul class="nav nav-tabs" id="tab-next-prev" role="tablist">
    <li class="nav-item">
      <a class="nav-link active" id="tab1-tab" data-toggle="tab" href="#tab1" role="tab" aria-controls="tab1" aria-selected="true">Tab 1</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" id="tab2-tab" data-toggle="tab" href="#tab2" role="tab" aria-controls="tab2" aria-selected="false">Tab2</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" id="tab3-tab" data-toggle="tab" href="#tab3" role="tab" aria-controls="tab3" aria-selected="false">Tab 3</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" id="tab4-tab" data-toggle="tab" href="#tab4" role="tab" aria-controls="tab4" aria-selected="false">Tab 4</a>
    </li>
  </ul>
  <div class="tab-content" id="tab-next-prev-content">
    <div class="tab-pane fade show active" id="tab1" role="tabpanel" aria-labelledby="tab1-tab">
      <p>Content tab 1.</p>
      <a href="#" role="button" class="btn btn-secondary btn-tab-next">Next</a>
    </div>
    <div class="tab-pane fade" id="tab2" role="tabpanel" aria-labelledby="tab2-tab">
      <p>Content tab 2.</p>
      <a href="#" role="button" class="btn btn-secondary btn-tab-prev">Previous</a>
      <a href="#" role="button" class="btn btn-secondary btn-tab-next">Next</a>
    </div>
    <div class="tab-pane fade" id="tab3" role="tabpanel" aria-labelledby="tab3-tab">
      <p>Content tab 3.</p>
      <a href="#" role="button" class="btn btn-secondary btn-tab-prev">Previous</a>
      <a href="#" role="button" class="btn btn-secondary btn-tab-next">Next</a>
    </div>
    <div class="tab-pane fade" id="tab4" role="tabpanel" aria-labelledby="tab4-tab">
      <p>Content tab 4.</p>
      <a href="#" role="button" class="btn btn-secondary btn-tab-prev">Previous</a>
    </div>
  </div>
</div>
-->




</body>
</html>
<script>
	// Pagination script
(function() {
  $('.btn-tab-prev').on('click', function(e) {
    e.preventDefault()
    $('#' + $('.nav-item > .active').parent().prev().find('a').attr('id')).tab('show')
  })
  $('.btn-tab-next').on('click', function(e) {
    e.preventDefault()
    $('#' + $('.nav-item > .active').parent().next().find('a').attr('id')).tab('show')
  })
})();
</script>