
 <?php 
    include('tags3.php');
    $username_session = $_SESSION['username'];
    ?>
<body>
    <div class="wrapper">
        <nav id="sidebar">
    <!--
            <div id="dismiss">
                <i class="fas fa-arrow-left"></i>
            </div>
-->
            <div class="sidebar-header" style="margin-top: 50px;">
                <h3>Welcome, <?php echo $username_session; ?></h3>
            </div>

            <ul class="list-unstyled">
                
            <li class="active">
               
                    <a href="#">Menu</a>
                </li>
                <li>
                    <a href="user_scores.php">View Scores</a>
                </li>
                <li>
                    <a href="#">Certificate</a>
                </li>
                 <li>
                    <a href="logout.php">Log Out</a>
                </li>
 <!--
            <li class="active">
               
                    <a href="admin_dashboard.php">Dashboard</a>
                </li>
                <li>
                    <a href="admin_managemodules.php">Manage Modules and Lesson Contents</a>
                </li>
                <li>
                    <a href="#">Manage Questions and Answers</a>
                </li>
                 <li>
                    <a href="#">Manage Credentials</a>
                </li>

                 <li>
                    <a href="logout.php">Log Out</a>
                </li>
            -->
            </ul>

            <ul class="list-unstyled CTAs">
                <li>
                    <a href="" class="download">About</a>
                </li>
                <li>
                    <a href="" onclick="goBack()" class="article">Back</a>
                </li>
            </ul>
        </nav>

        <nav class="navbar navbar-fixed-top navbar-expand-lg" style="background: #6c63ff;">
                <div class="container-fluid">

                        <button type="button" class="btn btn-info d-inline-block d-lg-none mr-auto" style="background: #6c63ff; border-color: #6c63ff;">
                            <div id="dismiss">
                            <i class="fas fa-arrow-left"></i>
                            <span></span>
                        </div>
                        </button>
                    

                    <h4 class="text-white font-weight-bold">IMeLT</h4>
                    <button type="button" id="sidebarCollapse" class="btn btn-info d-inline-block d-lg-none ml-auto" style="background: #6c63ff; border-color: #6c63ff;">
                        <i class="fas fa-ellipsis-v"></i>
                        <span></span>
                    </button>


                   
                </div>
            </nav>
    </div>



    
</body>
<script>
    function goBack() {
      window.history.back();
    }
</script>