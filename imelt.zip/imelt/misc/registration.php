<?php 
include('connection.php');
include('tags.php');

session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>

 body {
           /*
 background-image: linear-gradient(
    rgba(0, 0, 0, 0.1),
    rgba(0, 0, 0, 0.1)
    ), url("../img/imus_bg.png");
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: center center;
  background-size: cover;
 */
     overflow-x: hidden !important;
     overflow-y: hidden !important;
     
 }
 .box {
    display: table;
    width: 100%;
    height: 100vh;
    background: white;
    margin-top: -20px;
}
.box-cell {
    display: table-cell;
    vertical-align: middle;
    zoom: 90%;
    
    
}
.login-box-cell {
    width: 500px;
    margin: auto;
    
    padding: 15px; 
}
.login-panel {
    box-shadow: 0 2px 2px 0 rgba(0,0,0,0.14), 0 3px 1px -2px rgba(0,0,0,0.12), 0 1px 5px 0 rgba(0,0,0,0.2);
    padding: 30px 35px 5px 35px; /* top, right, down, left */
    border-radius: 6px;
}
.alertClass {
   width: 100% !important;
   padding: -15px !important;
}
@media only screen and (max-width: 991px){
.box {
    width: 100%;
}
}
@media (min-width:320px)  { /* smartphones, portrait iPhone, portrait 480x320 phones (Android) */ }
@media (min-width:480px)  { /* smartphones, Android phones, landscape iPhone */ }
@media (min-width:600px)  { /* portrait tablets, portrait iPad, e-readers (Nook/Kindle), landscape 800x480 phones (Android) */ }
@media (min-width:801px)  { /* tablet, landscape iPad, lo-res laptops ands desktops */ }
@media (max-width:1025px) { .d-none-pic {display:none;} /* big landscape tablets, laptops, and desktops */ }
@media (min-width:1281px) { /* hi-res laptops and desktops */ }

</style>
</head>
<body>
<div class="row h-100">
    <div class="col-lg-6" style="background-color: white;">
        <div class="box">
            <div class="box-cell">            
            <a href="../user/index.php"><button class="btn btn-primary" style="margin-left: 20px;">Back</button></a>
                <div class="login-box-cell">
                    <div class="login-panel">
                        <div class="row text-center">
                            <img src="../img/icon2.png" width="100"/>
                    </div>
                    <h6 class="text-center mt-4 mb-3" style="font-size: 18px; margin-top: 20px; margin-bottom: 20px;">Imus Institute of Science and Technology</h6>
                    <h6 class="text-center mb-4 lead" style="font-size: 15px;">Registration Form</h6>
                       
                       
                        <form action="" method="post">
                            <div class="form-group-sm">
                                <h6 for="usr" style="font-size: 14px;">Last Name:</h6>
                                <input type="text" style="font-size: 13px;" name="last_name" class="form-control mb-2" required>
                            </div>
                            <div class="form-group-sm">
                                <h6 for="usr" style="font-size: 14px;">First Name:</h6>
                                <input type="text" style="font-size: 13px;" name="first_name" class="form-control mb-2" required>
                            </div>
                            <div class="form-group-sm">
                                <h6 for="usr" style="font-size: 14px;" >Middle Name:</h6>
                                <input type="text" style="font-size: 13px;" name="middle_name" class="form-control mb-2">
                            </div>
                            <div class="row">
                                <div class="form-group-sm col-lg-6">
                                    <h6 for="username" style="font-size: 14px;">Username:</h6>
                                    <input type="text" style="font-size: 13px;" name="username" class="form-control" maxlength="11" required>
                                    <center>
                                        <h6 class="mt-2" style="font-size: 12px; color: blue;">Maximum of 11 digits only</h6>
                                    </center>  
                                </div>
                                <div class="form-group-sm col-lg-6">
                                    <h6 for="password" style="font-size: 14px;">Password:</h6>
                                    <input type="password" style="font-size: 13px;" name="password" class="form-control" maxlength="11" required>
                                    <center>
                                        <h6 class="mt-2 " style="font-size: 12px; color: blue;">Maximum of 11 digits only</h6>
                                    </center>  
                                </div>
                            </div>
                        <div class="row mt-4" style="margin-top: 20px;">
                            <div class="col-lg-8">
                               <div class="form-group-sm">
                                    <span style="font-size: 13px;">Already have an account? </span><a href="login.php" style="font-size: 13px;" >Log In Here</a>
                               </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group-sm mb-4">
                                    <span><input type="submit" class="btn btn-block btn-primary" value="SIGN UP" name="addData"></span>
                                </div>
                            </form>
                        </div>



                        </div>
                        <?php 
  if(isset($_POST["addData"]))
     {
        $last_name = $_POST['last_name'];
        $first_name = $_POST['first_name'];
        $middle_name = $_POST['middle_name'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $subquery = mysqli_query($conn, "SELECT * FROM tbl_admin_credentials");
        
        $query = mysqli_query($conn, "SELECT * FROM tbl_admin_credentials WHERE username='$username'");
         if(mysqli_num_rows($query) > 0) 
         {
             echo '<div class="alert alert-danger" style="width: 100% !important;">
             <center> 
             <button type="button" class="close" data-dismiss="alert">&times;</button>
             The username you entered already exists.
             </center>
        </div>';
         }
         elseif(mysqli_num_rows($subquery) > 2){  
                echo '<div class="alert alert-danger" style="width: 100% !important;">
                <center> 
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                You reached the level of user. Check the admin credentials.
                </center>
           </div>';
  }
         else 
         {
            $query_insert = mysqli_query($conn, "INSERT INTO tbl_admin_credentials 
                VALUES('', '$last_name', '$first_name', '$middle_name', 
                '$username', '$password')");
            if($query_insert)
            {            
            echo ' <div class="alert alert-success" style="width: 100% !important;">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
             
            <center> Registration successfully. </center>
                    </div>';           
            }
          }
      }
?>  
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6 hide-lg d-none-pic">
        <img src="../img/imus_bg.png"  style="height: 100vh !important; zoom: 100%;"/>
    </div>
</div>
</body>
</html>

<script>
/* Optional but not required 
$("#alert-success").fadeTo(2000, 500).slideUp(500, function(){
    $("#alert-success").slideUp(500);
});
$("#alert-danger").fadeTo(5000, 500).slideUp(500, function(){
    $("#alert-danger").slideUp(500);
});
*/
</script>