
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>IMeLT</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

    <!-- Favicons -->
  <link href="login/assets/img/favicon2.png" rel="icon">
  <link href="login/assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="login/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="login/assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="login/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="login/assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="login/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="login/assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="login/assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="login/assets/css/style.css" rel="stylesheet">
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">

      <div class="logo mr-auto">
        <h1 class="text-light"><a href="index.php"><span>IMeLT</span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li><a href="misc/login.php" data-toggle="modal" data-target="#myModal">Login</a></li>

        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero">

    <div class="container">
      <div class="row">
        <div class="col-lg-7 pt-5 pt-lg-0 order-2 order-lg-1 d-flex align-items-center">
          <div data-aos="zoom-out">
            <h1>Create your future. Welcome to <span>IMeLT</span></h1>
            <h2 class="lead">IMeLT (Introduction to Meteorology Learning Tool) is a learning tool that provides the lessons of the subject, Introduction to Meteorology. It includes modules of lessons with pre-test and post-test as one of it's features.</h2>
            <div class="text-center text-lg-left">
              <a href="misc/login.php" class="btn-get-started scrollto" data-toggle="modal" data-target="#myModal">Get Started</a>
            </div>
          </div>
        </div>
        <div class="col-lg-5 order-1 order-lg-2 hero-img" data-aos="zoom-out" data-aos-delay="300">
          <img src="login/assets/img/hero-img6.png" class="img-fluid animated" alt="">
        </div>
      </div>
    </div>

    <svg class="hero-waves" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 24 150 28 " preserveAspectRatio="none">
      <defs>
        <path id="wave-path" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z">
      </defs>
      <g class="wave1">
        <use xlink:href="#wave-path" x="50" y="3" fill="rgba(255,255,255, .1)">
      </g>
      <g class="wave2">
        <use xlink:href="#wave-path" x="50" y="0" fill="rgba(255,255,255, .2)">
      </g>
      <g class="wave3">
        <use xlink:href="#wave-path" x="50" y="9" fill="#fff">
      </g>
    </svg>

  </section><!-- End Hero -->

  <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog modal-dialog-centered modal-sm">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h5 class="modal-title text-center">Choose an User type</h5>
         <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
        <a href="misc/admin_login.php"  class="btn btn-block text-white" style="background: rgba(1, 4, 136, 0.9); border-radius: 30px;">Login as Admin</a>
        
        <a href="misc/login.php"  class="btn btn-block" style="color: rgba(1, 4, 136, 0.9); border: solid 1px rgba(1, 4, 136, 0.9); border-radius: 30px;">Login as User</a>
        </div>
        
        <!-- Modal footer -->
        <!--
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      -->
        </div>
        
      </div>
    </div>
  </div>
 
  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>
  <div id="preloader"></div>
  <!-- Vendor JS Files -->
  <script src="login/assets/vendor/jquery/jquery.min.js"></script>
  <script src="login/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="login/assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="login/assets/vendor/php-email-form/validate.js"></script>
  <script src="login/assets/vendor/venobox/venobox.min.js"></script>
  <script src="login/assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="login/assets/vendor/counterup/counterup.min.js"></script>
  <script src="login/assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="login/assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="login/assets/js/main.js"></script>
 
</body>

</html>